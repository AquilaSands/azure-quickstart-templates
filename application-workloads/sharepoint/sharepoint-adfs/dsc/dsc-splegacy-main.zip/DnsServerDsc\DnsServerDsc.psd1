@{
    # Version number of this module.
    moduleVersion     = '3.0.3'

    # ID used to uniquely identify this module
    GUID              = '5f70e6a1-f1b2-4ba0-8276-8967d43a7ec2'

    # Author of this module
    Author            = 'DSC Community'

    # Company or vendor of this module
    CompanyName       = 'DSC Community'

    # Copyright statement for this module
    Copyright         = 'Copyright the DSC Community contributors. All rights reserved.'

    # Description of the functionality provided by this module
    Description       = 'This module contains DSC resources for the management and configuration of Windows Server DNS Server.'

    # Minimum version of the Windows PowerShell engine required by this module
    PowerShellVersion = '5.0'

    # Script module or binary module file associated with this manifest.
    RootModule = 'DnsServerDsc.psm1'

    # Functions to export from this module
    FunctionsToExport = @()

    # Cmdlets to export from this module
    CmdletsToExport   = '*'

    # Variables to export from this module
    VariablesToExport = @()

    # Aliases to export from this module
    AliasesToExport   = @()

    DscResourcesToExport = @('DnsRecordCname','DnsRecordPtr','DnsRecordA','DnsRecordAaaa','DnsRecordMx','DnsRecordNs','DnsRecordSrv','DnsRecordTxt','DnsServerCache','DnsServerDsSetting','DnsServerEDns','DnsServerRecursion','DnsServerScavenging','DnsRecordAaaaScoped','DnsRecordAScoped','DnsRecordCnameScoped','DnsRecordMxScoped','DnsRecordNsScoped','DnsRecordSrvScoped','DnsRecordTxtScoped','DnsServerADZone','DnsServerClientSubnet','DnsServerConditionalForwarder','DnsServerDiagnostics','DnsServerForwarder','DnsServerPrimaryZone','DnsServerRootHint','DnsServerSecondaryZone','DnsServerSetting','DnsServerSettingLegacy','DnsServerZoneAging','DnsServerZoneScope','DnsServerZoneTransfer')

    <#
      Private data to pass to the module specified in RootModule/ModuleToProcess.
      This may also contain a PSData hashtable with additional module metadata used by PowerShell.
    #>
    PrivateData       = @{
        PSData = @{
            # Set to a prerelease string value if the release should be a prerelease.
            Prerelease   = ''

            # Tags applied to this module. These help with module discovery in online galleries.
            Tags         = @('DesiredStateConfiguration', 'DSC', 'DSCResourceKit', 'DSCResource')

            # A URL to the license for this module.
            LicenseUri   = 'https://github.com/dsccommunity/DnsServerDsc/blob/main/LICENSE'

            # A URL to the main website for this project.
            ProjectUri   = 'https://github.com/dsccommunity/DnsServerDsc'

            # A URL to an icon representing this module.
            IconUri = 'https://dsccommunity.org/images/DSC_Logo_300p.png'

            # ReleaseNotes of this module
            ReleaseNotes = '## [3.0.3] - 2026-01-18

### Added

- build.yml
  - Added config for merge task.

### Changed

- Pipelines
  - Used matrix strategy to test OSes.
- Integration tests
  - Updated file name casing.

### Fixed

- Tests
  - Remove use of -TestCases and replace with -ForEach.
  - Update tests for class-based resources which use DscResource.Base.
- DnsServerCache
  - Cast properties which were timestamps to strings.
- DnsServerDsSetting
  - Cast properties which were timestamps to strings.
- DnsServerEDns
  - Cast properties which were timestamps to strings.
- DnsServerScavenging
  - Cast properties which were timestamps to strings.
- Some integration test files were in Tests not tests.
- README
  - Updated PowerShell Gallery Preview badge.

### Removed

- Ensure Enum
  - This is provided by DscResource.Base.
- build.psd1

'
        } # End of PSData hashtable
    } # End of PrivateData hashtable
}
